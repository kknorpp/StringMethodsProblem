package newton_sqrt;

import java.util.Scanner;

public class newtonsMethod {
	public static void main(String[] args) {
		Scanner keyInput = new Scanner(System.in);

		System.out.print("Enter in N for force in Newtons: ");

		double accuracy = .00000001; // actual accuracy needed for same output as rubric used here.
		// .000001 is not accurate enough to mirror that output, used more accurate
		// representation.
		double n = keyInput.nextDouble();
		double n1 = n;

		while (Math.abs(n1 - n / n1) > accuracy * n1) {
			n1 = (n / n1 + n1) / 2;

		}
		System.out.printf("Newton(" + n + ") = " + n1);
		System.out.println();
		System.out.println("Math.sqrt = " + Math.sqrt(n));
	}

}
