package string_methods;

import java.util.Scanner;

public class StringMethodsOG {

	private String myStr = "";

	public void readString() {
		System.out.println("Please enter a short sentence.");
		Scanner keyEntry = new Scanner(System.in);
		this.myStr = keyEntry.nextLine();

	}

	public void setString(String s) {
		this.myStr = s;

	}

	public int countOccurrences(String s) {
		int sCount = 0;
		for (int f = 0; f < this.myStr.length(); f++) {
			f = this.myStr.indexOf(s);

			if (this.myStr.charAt(f) == 's') {
				sCount++;

			}

		}
		return sCount;

	}

	public int countOccurrences(char c) {
		int length = this.myStr.length();
		int cCount = 0;
		int index = 0;
		int z = 0;
		char characterC = 'c';
		while (index <= length) {
			int y = this.myStr.indexOf(characterC);
			z = z + 1;

			if (this.myStr.charAt(y) == 'c') {
				cCount = cCount + 1;

			}
			index = index + 1;

		}
		return cCount;
	}

	int countUpperCaseLetters() {
		int upperCaseCount = 0;
		for (int d = 0; d <= this.myStr.length(); d++) {
			for (char e = 'A'; e <= 'Z'; e++) {
				upperCaseCount++;
			}

		}

		return upperCaseCount;

	}

	public int countLowerCaseLetters() {
		int lowerCaseCount = 0;
		for (int y = 0; y <= this.myStr.length(); y++) {
			for (char c = 'a'; c <= 'z'; c++) {
				lowerCaseCount++;

			}
		}
		return lowerCaseCount;
	}

	public void printCounts(String s, char c) {
		System.out.println("*******************************************");
		System.out.println("Analyzing: myStr = " + this.myStr);
		System.out.println("Number of Upper case letters = " + countUpperCaseLetters());
		System.out.println("Number of Lower case letters = " + countLowerCaseLetters());
		System.out.println("Nmber of " + s + " is " + countOccurrences(s));
		System.out.println("Nmber of " + c + " is " + countOccurrences(c));
	}

	public static void main(String[] args) {
		StringMethodsOG msm = new StringMethodsOG();
		msm.readString();
		msm.printCounts("big", 'a');

		msm.setString(
				"Parked in a van down by the river bank .... " + "The van evan vanished near a lot of other vans");
		msm.printCounts("van", 'a');
		StringMethodsOG msm2 = new StringMethodsOG();
		msm2.setString("the elephant in the room wouldn't budge");
		msm2.printCounts("the", 'i');

	}

}
